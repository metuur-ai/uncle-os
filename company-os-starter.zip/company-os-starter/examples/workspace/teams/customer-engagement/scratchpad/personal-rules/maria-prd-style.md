---
type: personal-rule
tags: [authority/personal, kind/personal-rule, process/prd]
---

# Maria's personal PRD rules (applied ON TOP of the canonical skill)

- Draft the Problem statement as a customer quote first, then generalize.
- Always add a "What we are NOT doing" line to Out of scope.
- Ask my agent to challenge every success metric with "how could this number
  lie to us?" before I fill it in.

<!-- Note: these personal rules can reorder or enrich default/guidance steps,
     but mandatory steps from skill://product/creating-prd always win. -->
