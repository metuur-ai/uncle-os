---
type: doc
tags: [doc/company-os-starter, kind/readme]
---

# company-os Starter Kit

Reference implementation of the Federated Company / Platform / Team OS:
tiered governance (mandatory / default / guidance), canonical skills,
a guiding CLI, validation gates, and a fully worked example.

## Contents

```text
bin/company-os        Reference CLI (Python 3.9+, needs: pip install pyyaml)
templates/            Artifact templates (discovery, PRD, ADR, outcome,
                      reality doc, deviations, exceptions, SKILL template)
skills/               Canonical skills: running-discovery, creating-prd,
                      completing-a-change, requesting-an-exception
schemas/SCHEMAS.md    Human-readable artifact contracts
docs/TUTORIAL.md      End-to-end walkthrough with real command outputs
examples/workspace/   Populated company + platform + team, including a
                      completed PRD, deviations, an exception, and a
                      personal-rules example in scratchpad/
```

## Quick start

```bash
pip install pyyaml
export PATH="$PWD/bin:$PATH"
cd examples/workspace
company-os governance resolve --team customer-engagement
company-os today --role product-owner
company-os validate
```

Then follow `docs/TUTORIAL.md` for the full discovery → PRD → complete loop.

## Design rules encoded here

1. Strict on artifacts, flexible on process — validators check outputs, never methods.
2. Rules have tiers; mandatory rules are outcomes, not implementations.
3. Deviations (default rules) and exceptions (mandatory rules) are explicit,
   expiring, and validated in CI.
4. Component descriptors are the single source for platform links and ownership;
   everything else is reconciled against them.
5. A change is done only when the Representation of Reality is updated —
   `prd complete` enforces it.
6. `generated/` files are derived, never hand-edited; CI regenerates and diffs.
7. Personal skills live in git-ignored `scratchpad/personal-rules/` and layer
   on top of canonical skills; mandatory steps always win.
